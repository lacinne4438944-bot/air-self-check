# 휴대폰용 고정 HTTPS 주소 배포

이 프로젝트는 Render Blueprint 방식으로 바로 배포할 수 있게 준비되어 있습니다.

## 1. GitHub 저장소 만들기
- GitHub에서 새 저장소를 만듭니다.
- 이 폴더의 파일 전체를 저장소 루트에 올립니다.
- `OPENAI_API_KEY` 실제 값은 어떤 파일에도 적지 마세요.

## 2. Render에서 Blueprint 생성
- Render 로그인
- New → Blueprint
- 방금 만든 GitHub 저장소 연결
- Render가 루트의 `render.yaml`을 읽습니다.

## 3. 비밀값 입력
Blueprint 생성 중 또는 생성 후 Environment에서 아래 값을 입력합니다.
- `OPENAI_API_KEY`: 본인 OpenAI API 키
- `APP_PIN`: 현장 접속용 PIN

`OPENAI_MODEL`은 기본 `gpt-6-luna`로 설정되어 있습니다.

## 4. 배포 확인
Health Check:
- `/api/health`

배포 성공 후 Render가 다음과 같은 HTTPS 주소를 만듭니다.
- `https://air-selfcheck-xxxx.onrender.com`

이 주소를 휴대폰 Chrome/Safari에서 열면 됩니다.

## 5. 현장 사용
1. 시설현황 페이지만 촬영/업로드
2. 오염물질 발생량 페이지만 촬영/업로드
3. 자가측정 주기 분석
4. PIN 입력
5. 결과 확인

## 주의
- 무료 플랜은 일정 시간 사용하지 않으면 첫 접속 시 시작 시간이 걸릴 수 있습니다.
- 실제 기관 운영 전에는 외부 클라우드 및 외부 API 사용 정책을 확인하세요.
