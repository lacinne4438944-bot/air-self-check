from __future__ import annotations

import os
from typing import Any

from openai_extractor import (
    file_to_page_images,
    extract_facility_pages,
    extract_emission_pages,
    merge_focused,
)
from rule_engine import determine_outlet, pollutant_frequency


def _norm_pollutant(name: str) -> str:
    s = (name or "").strip()
    low = s.lower()
    if low == "nox" or s == "질소 산화물":
        return "질소산화물"
    if low == "sox" or s == "황 산화물":
        return "황산화물"
    return s


def _summary(o: dict[str, Any]) -> str:
    parts = []
    facilities = list(dict.fromkeys(o.get("facility_names") or []))
    controls = list(dict.fromkeys(o.get("control_names") or []))
    if facilities:
        txt = " · ".join(facilities[:5])
        if len(facilities) > 5:
            txt += f" 외 {len(facilities)-5}개"
        parts.append(txt)
    if controls:
        parts.append("방지시설: " + " · ".join(controls[:3]))
    if o.get("low_nox_burner"):
        parts.append("저NOx버너")
    return " / ".join(parts)


def analyze_files(
    facility_files: list[tuple[str, bytes]],
    emission_files: list[tuple[str, bytes]]
) -> dict[str, Any]:
    if not facility_files:
        raise ValueError("시설현황 자료를 1개 이상 올려주세요.")
    if not emission_files:
        raise ValueError("오염물질 발생량 자료를 1개 이상 올려주세요.")

    max_files = int(os.getenv("MAX_FILES", "40"))
    all_files = facility_files + emission_files
    if len(all_files) > max_files:
        raise ValueError(f"한 번에 최대 {max_files}개 파일까지 분석할 수 있습니다.")

    facility_pages = []
    for filename, data in facility_files:
        facility_pages.extend(file_to_page_images(data, filename))

    emission_pages = []
    for filename, data in emission_files:
        emission_pages.extend(file_to_page_images(data, filename))

    f_extract = extract_facility_pages(facility_pages)
    e_extract = extract_emission_pages(emission_pages)

    valid_f = [x for x in f_extract if x.get("valid_facility_page")]
    valid_e = [x for x in e_extract if x.get("valid_emission_page")]

    invalid_facility = [x for x in f_extract if not x.get("valid_facility_page")]
    invalid_emission = [x for x in e_extract if not x.get("valid_emission_page")]

    if not valid_f:
        raise ValueError("시설현황으로 인식된 페이지가 없습니다. 시설명·오염물질·방지시설·배출구가 보이는 페이지만 올려주세요.")
    if not valid_e:
        raise ValueError("오염물질 발생량 자료로 인식된 페이지가 없습니다. 오염물질명과 연간 발생량(톤/년)이 보이는 페이지만 올려주세요.")

    merged = merge_focused(valid_f, valid_e)

    out = []
    for o in merged.get("outlets", []):
        e = o.get("emissions_tpy") or {}
        has_data = bool(o.get("emission_data_complete"))
        result = determine_outlet(
            o.get("outlet_id") or "미확인",
            dust=e.get("먼지"),
            sox=e.get("황산화물"),
            nox=e.get("질소산화물"),
            has_emission_data=has_data,
        )

        names = [_norm_pollutant(x) for x in (o.get("pollutants") or [])]
        for std in ("먼지","황산화물","질소산화물"):
            if e.get(std) is not None and std not in names:
                names.append(std)
        exemptions = {_norm_pollutant(x) for x in (o.get("prevention_exempt_pollutants") or [])}

        pollutants = []
        for p in dict.fromkeys(names):
            if not p:
                continue
            if result.grade is None:
                freq = "종수 확인 후 판정"
                notes = ["발생량 자료 확인 필요"]
                needs = True
            else:
                freq, notes = pollutant_frequency(
                    result.grade,
                    p,
                    prevention_exempt=p in exemptions,
                    low_nox_burner=bool(o.get("low_nox_burner")),
                    low_nox_omission_approved=False,
                )
                needs = False

            emission = e.get(p) if p in {"먼지","황산화물","질소산화물"} else None
            note_parts = []
            if emission is not None:
                note_parts.append(f"발생량 {emission:g}톤/년")
            note_parts.extend(notes)
            pollutants.append({
                "name":p,
                "frequency":freq,
                "note":" · ".join(note_parts),
                "needs_review":needs
            })

        needs_review = result.grade is None or not o.get("outlet_id")
        basis = [result.reason]
        if o.get("emission_data_note"):
            basis.append(o["emission_data_note"])
        if o.get("evidence_pages"):
            basis.append("근거 페이지: " + ", ".join(o["evidence_pages"][:8]))

        out.append({
            "outlet_no": o.get("outlet_id") or "미확인",
            "grade": result.grade,
            "annual_sum_tpy": result.annual_sum_tpy,
            "facility_summary": _summary(o),
            "needs_review": needs_review,
            "basis": " / ".join(x for x in basis if x),
            "pollutants": pollutants,
        })

    return {
        "outlets": out,
        "unresolved": merged.get("unresolved", []),
        "rejected_pages": {
            "facility": [
                {"page":x.get("source_page"),"reason":x.get("reason_if_invalid")}
                for x in invalid_facility
            ],
            "emission": [
                {"page":x.get("source_page"),"reason":x.get("reason_if_invalid")}
                for x in invalid_emission
            ]
        },
        "meta":{
            "facility_files":len(facility_files),
            "emission_files":len(emission_files),
            "facility_pages":len(facility_pages),
            "emission_pages":len(emission_pages),
            "model":os.getenv("OPENAI_MODEL","gpt-6-luna")
        }
    }
