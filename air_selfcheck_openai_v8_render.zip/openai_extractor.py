from __future__ import annotations

import base64
import io
import json
import os
from typing import Any

import fitz
from PIL import Image, ImageOps
from openai import OpenAI


def _client() -> OpenAI:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않았습니다.")
    return OpenAI(api_key=key)


def _model() -> str:
    return os.getenv("OPENAI_MODEL", "gpt-6-luna")


def _normalize_image(data: bytes, max_long_edge: int = 2200) -> tuple[bytes, str]:
    img = Image.open(io.BytesIO(data))
    img = ImageOps.exif_transpose(img)
    w, h = img.size
    longest = max(w, h)
    if longest > max_long_edge:
        scale = max_long_edge / longest
        img = img.resize(
            (max(1, round(w * scale)), max(1, round(h * scale))),
            Image.Resampling.LANCZOS,
        )

    if img.mode in {"RGBA", "LA"} or (img.mode == "P" and "transparency" in img.info):
        buf = io.BytesIO()
        img.convert("RGBA").save(buf, format="PNG", optimize=True)
        return buf.getvalue(), "image/png"

    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=88, optimize=True)
    return buf.getvalue(), "image/jpeg"


def file_to_page_images(file_bytes: bytes, filename: str, max_pages: int = 80):
    name = filename.lower()
    out = []
    if name.endswith(".pdf"):
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        try:
            for i, page in enumerate(doc):
                if i >= max_pages:
                    break
                pix = page.get_pixmap(matrix=fitz.Matrix(1.8, 1.8), alpha=False)
                normalized, media_type = _normalize_image(pix.tobytes("png"))
                out.append((f"{filename} - {i+1}쪽", normalized, media_type))
        finally:
            doc.close()
        return out

    normalized, media_type = _normalize_image(file_bytes)
    return [(filename, normalized, media_type)]


def _data_url(data: bytes, media_type: str) -> str:
    return f"data:{media_type};base64,{base64.b64encode(data).decode('ascii')}"


FACILITY_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "pages": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source_page": {"type": "string"},
                    "valid_facility_page": {"type": "boolean"},
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "facility_id": {"type": ["string", "null"]},
                                "facility_name": {"type": ["string", "null"]},
                                "equipment_tag": {"type": ["string", "null"]},
                                "pollutants": {"type": "array", "items": {"type": "string"}},
                                "control_id": {"type": ["string", "null"]},
                                "control_name": {"type": ["string", "null"]},
                                "outlet_id": {"type": ["string", "null"]},
                                "prevention_exempt": {"type": "boolean"},
                                "low_nox_burner": {"type": "boolean"},
                                "notes": {"type": ["string", "null"]},
                            },
                            "required": [
                                "facility_id","facility_name","equipment_tag","pollutants",
                                "control_id","control_name","outlet_id",
                                "prevention_exempt","low_nox_burner","notes"
                            ],
                            "additionalProperties": False,
                        }
                    },
                    "reason_if_invalid": {"type": ["string","null"]},
                },
                "required": ["source_page","valid_facility_page","rows","reason_if_invalid"],
                "additionalProperties": False,
            }
        }
    },
    "required": ["pages"],
    "additionalProperties": False,
}


EMISSION_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "pages": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source_page": {"type": "string"},
                    "valid_emission_page": {"type": "boolean"},
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "facility_ids": {"type": "array", "items": {"type": "string"}},
                                "facility_names": {"type": "array", "items": {"type": "string"}},
                                "control_id": {"type": ["string","null"]},
                                "control_name": {"type": ["string","null"]},
                                "pollutant": {"type": ["string","null"]},
                                "emission_tpy": {"type": ["number","null"]},
                                "notes": {"type": ["string","null"]},
                            },
                            "required": [
                                "facility_ids","facility_names","control_id","control_name",
                                "pollutant","emission_tpy","notes"
                            ],
                            "additionalProperties": False,
                        }
                    },
                    "reason_if_invalid": {"type": ["string","null"]},
                },
                "required": ["source_page","valid_emission_page","rows","reason_if_invalid"],
                "additionalProperties": False,
            }
        }
    },
    "required": ["pages"],
    "additionalProperties": False,
}


MERGE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "outlets": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "outlet_id": {"type": ["string","null"]},
                    "facility_ids": {"type": "array","items":{"type":"string"}},
                    "facility_names": {"type": "array","items":{"type":"string"}},
                    "control_ids": {"type":"array","items":{"type":"string"}},
                    "control_names": {"type":"array","items":{"type":"string"}},
                    "pollutants": {"type":"array","items":{"type":"string"}},
                    "prevention_exempt_pollutants": {"type":"array","items":{"type":"string"}},
                    "low_nox_burner": {"type":"boolean"},
                    "emissions_tpy": {
                        "type":"object",
                        "properties":{
                            "먼지":{"type":["number","null"]},
                            "황산화물":{"type":["number","null"]},
                            "질소산화물":{"type":["number","null"]}
                        },
                        "required":["먼지","황산화물","질소산화물"],
                        "additionalProperties":False
                    },
                    "emission_data_complete":{"type":"boolean"},
                    "emission_data_note":{"type":"string"},
                    "evidence_pages":{"type":"array","items":{"type":"string"}},
                },
                "required":[
                    "outlet_id","facility_ids","facility_names","control_ids","control_names",
                    "pollutants","prevention_exempt_pollutants","low_nox_burner",
                    "emissions_tpy","emission_data_complete","emission_data_note","evidence_pages"
                ],
                "additionalProperties":False
            }
        },
        "unresolved":{
            "type":"array",
            "items":{
                "type":"object",
                "properties":{
                    "item":{"type":"string"},
                    "reason":{"type":"string"},
                    "evidence_pages":{"type":"array","items":{"type":"string"}}
                },
                "required":["item","reason","evidence_pages"],
                "additionalProperties":False
            }
        }
    },
    "required":["outlets","unresolved"],
    "additionalProperties":False
}


def _response_json(client: OpenAI, name: str, schema: dict, content: list[dict]) -> dict:
    r = client.responses.create(
        model=_model(),
        store=False,
        input=[{"role":"user","content":content}],
        text={"format":{"type":"json_schema","name":name,"schema":schema,"strict":True}},
    )
    if not r.output_text:
        raise RuntimeError("OpenAI 응답에 구조화 결과가 없습니다.")
    return json.loads(r.output_text)


def _batch_pages(pages, instructions: str, schema: dict, name: str, batch_size: int = 4):
    client = _client()
    results = []
    for i in range(0, len(pages), batch_size):
        batch = pages[i:i+batch_size]
        content = [{"type":"input_text","text":instructions}]
        for label, data, media_type in batch:
            content.append({"type":"input_text","text":f"다음 이미지는 {label}이다."})
            content.append({"type":"input_image","image_url":_data_url(data, media_type),"detail":"high"})
        obj = _response_json(client, name, schema, content)
        results.extend(obj.get("pages",[]))
    return results


def extract_facility_pages(pages):
    instructions = """한국 대기배출시설 허가·신고 서류 중 '시설현황' 페이지 전용 분석기다.
다음 항목만 추출한다: 배출시설 번호/명칭, 설비태그, 오염물질, 방지시설 번호/명칭, 배출구 번호, 방지시설 설치면제, 저NOx버너.
사업장명, 주소, 대표자, 허가번호 등 일반정보는 추출하지 않는다.
시설현황 페이지가 아니면 valid_facility_page=false로 하고 rows=[]로 둔다.
표의 병합 셀과 여러 행 연결을 고려하되 추정하지 않는다."""
    return _batch_pages(pages, instructions, FACILITY_SCHEMA, "facility_pages")


def extract_emission_pages(pages):
    instructions = """한국 대기오염물질 발생량 산정자료 중 '오염물질 발생량' 페이지 전용 분석기다.
다음 항목만 추출한다: 배출시설 번호/명칭, 방지시설 번호/명칭, 오염물질명, 연간 발생량(톤/년).
사업장명, 주소, 대표자, 허가번호 등 일반정보는 추출하지 않는다.
발생량 페이지가 아니면 valid_emission_page=false로 하고 rows=[]로 둔다.
먼지, 황산화물(SOx), 질소산화물(NOx)은 한글 표준명으로 정규화한다.
표의 소계/합계는 개별 배출구 값과 혼동하지 않는다."""
    return _batch_pages(pages, instructions, EMISSION_SCHEMA, "emission_pages")


def merge_focused(facility_pages: list[dict], emission_pages: list[dict]) -> dict:
    client = _client()
    instructions = """동일 사업장의 시설현황과 오염물질 발생량 자료를 통합한다.
관리번호, 설비태그, 방지시설 번호, 방지시설명, 명확한 표 연결관계를 우선 사용한다.
발생량 자료가 방지시설 묶음 단위이면 시설현황의 동일 방지시설과 연결된 최종 배출구에 귀속한다.
동일 배출구의 시설은 병합하되 오염물질별로 유지한다.
배출구 종수 산정에 필요한 먼지+황산화물+질소산화물 자료가 충분한 경우에만 emission_data_complete=true.
누락인지 0인지 불명확하면 false.
법적 종수나 자가측정 주기는 계산하지 않는다."""
    payload = json.dumps(
        {"facility_pages":facility_pages,"emission_pages":emission_pages},
        ensure_ascii=False
    )
    return _response_json(
        client,
        "focused_merge",
        MERGE_SCHEMA,
        [{"type":"input_text","text":instructions},{"type":"input_text","text":payload}]
    )
