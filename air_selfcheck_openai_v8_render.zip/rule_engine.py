from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


BASE_NON_TMS = {
    1: "매주 1회 이상",
    2: "매월 2회 이상",
    3: "2개월마다 1회 이상",
    4: "반기마다 1회 이상",
    5: "반기마다 1회 이상",
}

BASE_TMS_POST_ONLY = {
    1: "2주마다 1회 이상",
    2: "매월 1회 이상",
    3: "2개월마다 1회 이상",
    4: "반기마다 1회 이상",
    5: "반기마다 1회 이상",
}

BASE_TMS_PRE_POST = {
    1: "매월 1회 이상",
    2: "2개월마다 1회 이상",
    3: "분기마다 1회 이상",
    4: "반기마다 1회 이상",
    5: "반기마다 1회 이상",
}


def outlet_grade(dust: float = 0.0, sox: float = 0.0, nox: float = 0.0) -> tuple[int, float]:
    total = max(0.0, float(dust or 0)) + max(0.0, float(sox or 0)) + max(0.0, float(nox or 0))
    if total >= 80:
        return 1, total
    if total >= 20:
        return 2, total
    if total >= 10:
        return 3, total
    if total >= 2:
        return 4, total
    return 5, total


def base_frequency(grade: int, tms_mode: str = "none") -> str:
    if tms_mode == "post_only":
        return BASE_TMS_POST_ONLY[grade]
    if tms_mode == "pre_post":
        return BASE_TMS_PRE_POST[grade]
    return BASE_NON_TMS[grade]


def pollutant_frequency(
    grade: int,
    pollutant: str,
    *,
    tms_mode: str = "none",
    prevention_exempt: bool = False,
    dust_only_with_bag_filter: bool = False,
    hazardous_over_threshold: bool = False,
    is_pah: bool = False,
    low_nox_burner: bool = False,
    low_nox_omission_approved: bool = False,
) -> tuple[str, list[str]]:
    p = (pollutant or "").strip().lower()
    notes: list[str] = []

    if low_nox_burner and p in {"nox", "질소산화물", "질소 산화물"} and low_nox_omission_approved:
        return "자가측정 생략 가능", ["저녹스버너 설치 + 관할 행정기관 인정 여부 확인"]

    if prevention_exempt:
        return "연 1회 이상", ["방지시설 설치면제 시설 특례 적용"]

    if is_pah:
        return "반기마다 1회 이상", ["다환방향족탄화수소 특례 적용"]

    if hazardous_over_threshold and grade in {3, 4, 5}:
        return "매월 2회 이상", ["특정대기유해물질 기준 이상 배출 특례 적용"]

    if dust_only_with_bag_filter and p in {"먼지", "dust"}:
        return "반기마다 1회 이상", ["먼지만 배출 + 여과집진시설 특례 적용"]

    return base_frequency(grade, tms_mode), notes


@dataclass
class OutletResult:
    outlet_id: str
    grade: Optional[int]
    annual_sum_tpy: Optional[float]
    status: str
    reason: str


def determine_outlet(outlet_id: str, dust=None, sox=None, nox=None, has_emission_data: bool = True) -> OutletResult:
    if not has_emission_data:
        return OutletResult(outlet_id, None, None, "확인 필요", "먼지·황산화물·질소산화물 연간 발생량 자료 필요")
    g, total = outlet_grade(dust or 0, sox or 0, nox or 0)
    return OutletResult(outlet_id, g, round(total, 6), "자동 산정", "먼지+황산화물+질소산화물 연간 발생량 합계로 산정")
