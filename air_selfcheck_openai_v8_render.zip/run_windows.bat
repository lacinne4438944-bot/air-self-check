@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Python virtual environment...
  python -m venv .venv || goto :error
)
echo [2/3] Installing/updating packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :error
echo [3/3] Starting web app...
".venv\Scripts\python.exe" server.py
goto :eof
:error
echo.
echo 실행 중 오류가 발생했습니다.
pause
