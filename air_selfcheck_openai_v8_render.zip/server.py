from __future__ import annotations

import os
from pathlib import Path
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from backend import analyze_files

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"

app = FastAPI(title="대기 자가측정 주기 판정", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=STATIC), name="static")

@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")

@app.get("/app.js")
def app_js():
    return FileResponse(STATIC / "app.js", media_type="application/javascript")

@app.get("/api/health")
def health():
    return {"ok":True}

def _check_pin(request: Request):
    required = os.getenv("APP_PIN","").strip()
    if not required:
        return
    if request.headers.get("x-app-pin","").strip() != required:
        raise HTTPException(status_code=401, detail="접속 PIN이 올바르지 않습니다.")

@app.post("/api/analyze")
async def analyze(
    request: Request,
    facility_files: list[UploadFile] = File(...),
    emission_files: list[UploadFile] = File(...),
):
    _check_pin(request)
    try:
        ff, ef = [], []
        for f in facility_files:
            data = await f.read()
            if data:
                ff.append((f.filename or "facility", data))
        for f in emission_files:
            data = await f.read()
            if data:
                ef.append((f.filename or "emission", data))
        return JSONResponse(analyze_files(ff, ef))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=int(os.getenv("PORT","8501")), reload=False)
