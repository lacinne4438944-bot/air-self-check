(() => {
const fInput=document.getElementById('facilityInput');
const eInput=document.getElementById('emissionInput');
const fList=document.getElementById('facilityList');
const eList=document.getElementById('emissionList');
const analyze=document.getElementById('analyzeBtn');
const progress=document.getElementById('progress');
const pText=document.getElementById('progressText');
const pBar=document.getElementById('progressBar');
const errorBox=document.getElementById('errorBox');
const results=document.getElementById('results');
const cards=document.getElementById('cards');
const reset=document.getElementById('resetBtn');
let facilityFiles=[], emissionFiles=[];

function addFiles(target,list){
  [...(list||[])].forEach(file=>{
    const key=`${file.name}-${file.size}-${file.lastModified}`;
    if(!target.some(x=>x._key===key)){file._key=key;target.push(file);}
  });
  render();
}
function drawList(el,arr){
  el.innerHTML=''; el.style.display=arr.length?'block':'none';
  arr.forEach((file,idx)=>{
    const row=document.createElement('div'); row.className='fileitem';
    const n=document.createElement('div');n.className='fname';n.textContent=file.name;
    const d=document.createElement('div');d.className='del';d.textContent='삭제';
    d.addEventListener('click',()=>{arr.splice(idx,1);render();});
    row.append(n,d);el.append(row);
  });
}
function render(){
  drawList(fList,facilityFiles); drawList(eList,emissionFiles);
  analyze.disabled=!(facilityFiles.length&&emissionFiles.length);
}
fInput.addEventListener('change',e=>{addFiles(facilityFiles,e.target.files);e.target.value='';});
eInput.addEventListener('change',e=>{addFiles(emissionFiles,e.target.files);e.target.value='';});

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function setP(t,p){progress.style.display='block';pText.textContent=t;pBar.style.width=Math.max(0,Math.min(100,p))+'%';}

function showResults(data){
  cards.innerHTML=''; const outlets=Array.isArray(data.outlets)?data.outlets:[];let done=0,warn=0;
  outlets.forEach(o=>{
    const needs=!!o.needs_review;needs?warn++:done++;
    const card=document.createElement('div');card.className='card';
    const poll=(o.pollutants||[]).map(p=>`<div class="poll"><div><div class="pname">${esc(p.name||'오염물질')}</div><div class="pnote">${esc(p.note||'')}</div></div><div class="freq ${p.needs_review?'warn':''}">${esc(p.frequency||'확인 필요')}</div></div>`).join('');
    card.innerHTML=`<div class="chead"><div class="outlet">배출구 ${esc(o.outlet_no||'미확인')}${o.grade?` · ${esc(o.grade)}종`:''}</div><div class="status ${needs?'warn':''}">${needs?'추가 확인':'판정 완료'}</div></div><div class="body"><div class="meta">${esc(o.facility_summary||'')}</div>${poll||'<div class="pnote">오염물질 정보 없음</div>'}<details><summary>판정 근거 보기</summary><div class="basis">${esc(o.basis||'근거 정보 없음')}</div></details></div>`;
    cards.append(card);
  });
  document.getElementById('sumOutlets').textContent=`${outlets.length}개`;
  document.getElementById('sumDone').textContent=`${done}개`;
  document.getElementById('sumWarn').textContent=`${warn}개`;
  document.getElementById('sumFiles').textContent=`${facilityFiles.length+emissionFiles.length}개`;
  results.style.display='block';results.scrollIntoView({behavior:'smooth',block:'start'});
}

analyze.addEventListener('click',async()=>{
  if(!(facilityFiles.length&&emissionFiles.length)) return;
  analyze.disabled=true;errorBox.style.display='none';results.style.display='none';setP('두 종류의 자료를 올리고 있습니다.',20);
  const fd=new FormData();
  facilityFiles.forEach(f=>fd.append('facility_files',f,f.name));
  emissionFiles.forEach(f=>fd.append('emission_files',f,f.name));
  try{
    setP('시설현황과 발생량을 연결하고 있습니다.',45);
    let pin=sessionStorage.getItem('aircheck_pin')||'';
    let res=await fetch('/api/analyze',{method:'POST',body:fd,headers:pin?{'X-App-PIN':pin}:{}});
    if(res.status===401){
      const entered=window.prompt('접속 PIN을 입력하세요.');
      if(entered===null) throw new Error('PIN 입력이 취소되었습니다.');
      pin=entered.trim();sessionStorage.setItem('aircheck_pin',pin);
      res=await fetch('/api/analyze',{method:'POST',body:fd,headers:pin?{'X-App-PIN':pin}:{}});
    }
    const body=await res.json().catch(()=>({}));
    if(!res.ok) throw new Error(body.detail||body.error||`서버 오류 ${res.status}`);
    setP('배출구 종수와 자가측정 주기를 계산하고 있습니다.',85);
    showResults(body);setP('분석이 완료되었습니다.',100);setTimeout(()=>progress.style.display='none',800);
  }catch(err){progress.style.display='none';errorBox.textContent='분석하지 못했습니다. '+err.message;errorBox.style.display='block';}
  finally{analyze.disabled=false;}
});
reset.addEventListener('click',()=>{facilityFiles=[];emissionFiles=[];render();cards.innerHTML='';results.style.display='none';errorBox.style.display='none';window.scrollTo({top:0,behavior:'smooth'});});
render();
})();