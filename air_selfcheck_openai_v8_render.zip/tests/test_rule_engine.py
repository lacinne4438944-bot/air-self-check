from rule_engine import outlet_grade, pollutant_frequency, determine_outlet


def test_grades():
    assert outlet_grade(0.5, 0.5, 0.5)[0] == 5
    assert outlet_grade(2, 0, 0)[0] == 4
    assert outlet_grade(10, 0, 0)[0] == 3
    assert outlet_grade(20, 0, 0)[0] == 2
    assert outlet_grade(80, 0, 0)[0] == 1


def test_missing_data():
    r = determine_outlet("#1", None, None, None, False)
    assert r.grade is None
    assert r.status == "확인 필요"


def test_prevention_exempt():
    freq, notes = pollutant_frequency(2, "먼지", prevention_exempt=True)
    assert freq == "연 1회 이상"
    assert notes


def test_low_nox_approved():
    freq, notes = pollutant_frequency(2, "NOx", low_nox_burner=True, low_nox_omission_approved=True)
    assert "생략" in freq
